@echo off
start "" /D "%~dp0" "%~dp0PingPK.exe"
